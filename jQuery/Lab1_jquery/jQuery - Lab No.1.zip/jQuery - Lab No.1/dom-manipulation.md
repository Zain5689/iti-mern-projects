1. In Section with class 'container1' =>
	- Append new Div with class 'black'.
	- Add new Div with class 'white' as the first child of the section.
	- Insert new <P> with class 'yellow' before <P> with class 'pink'.

2. In Section with class 'container2' => 
	- Replace every P of the section with anchor with the same textContent and give it a href attribute ["http://"+textContent].

3- In Section with class 'container3' =>
	- wrap the image with figure element.
	- insert new <figcaption> with text Content "Coffee" after the image.

4. In Section with class 'container4' =>
	- Empty all <td> with class 'col-age'.
	- Add Class 'man' to the td which contains 'mohsen'.
	- Remove class 'your-email' from all <td> which has it and add it to all <td> which has not.
	  [Solve it in One Step][Bonus: more than two steps].



5- [][Bonus] In Section with class 'container 5' =>
	- Filter The <li> and return only that has index that can be divided by 3.

6- In Section with class 'container 6' =>
	- Change the value of input which named "username" to <yourname>
	- Make the checkbox in the form with id 'my-form' checked.